#!python3

import os
import time
import math

import ntnx_networking_py_client
import ntnx_vmm_py_client
import ntnx_prism_py_client
import ntnx_networking_py_client.models
import ntnx_networking_py_client.models.networking
import ntnx_networking_py_client.models.common.v1.config as v1CommonConfig
import ntnx_networking_py_client.models.networking.v4.config as v4NetConfig
import requests
import uuid
from ntnx_vmm_py_client.models.vmm.v4.ahv.config.CloneOverrideParams import CloneOverrideParams
from ntnx_vmm_py_client.models.vmm.v4.ahv.config.Nic import Nic
from ntnx_vmm_py_client.models.vmm.v4.ahv.config.NicNetworkInfo import NicNetworkInfo
from ntnx_vmm_py_client.models.vmm.v4.ahv.config.SubnetReference import SubnetReference
from ntnx_vmm_py_client.rest import ApiException as VMMException
from jsonpath_ng.ext import parse
import json

import urllib3
urllib3.disable_warnings()

# Load environment variables
#load_dotenv()

# Customizable variables
prismCentralIp = "@@{pcAddress}@@"  # Prism Central IP
pcUsername = "@@{pcUser.username}@@"  # Nutanix username
pcPassword = "@@{pcUser.secret}@@"  # Nutanix password
vpcName = "@@{vpcName}@@"
categoryName = "@@{categoryName}@@"
categoryValue = "@@{categoryValue}@@"
externalNetworkName = "@@{externalNetworkName}@@"
categoryFloatingIPName = "@@{categoryFloatingIPName}@@"
categoryFloatingIPValue = "Yes"
# Retry parameters
max_wait_time = 60  # maximum wait time in seconds
interval = 1        # interval between retries in seconds

# Subnet configuration
subnetList = {
    "vpc-"+vpcName+"-subnet": {
        "subnetDescription": "This is the overlay subnet",
        "ipNetwork": "10.55.182.0",
        "ipPrefix": 25,
        "ipGateway": "10.55.182.1",
        "ipPoolStart": "10.55.182.10",
        "ipPoolEnd": "10.55.182.120"
    },
}

#########################################
# SDK Client Configuration
#########################################

# Configure the client
sdkConfig = ntnx_networking_py_client.Configuration()
sdkConfig.host = prismCentralIp
sdkConfig.port = 9440
sdkConfig.maxRetryAttempts = 3
sdkConfig.backoffFactor = 3
sdkConfig.username = pcUsername
sdkConfig.password = pcPassword
sdkConfig.verify_ssl = False


# Function to check if a VPC exists
def checkVpcExists(vpcData, vpcName):
    if vpcData:
      for vpc in vpcData:
          if vpc.name == vpcName:
              return vpc._ExternalizableAbstractModel__ext_id
    return False

# Function to wait for VPC creation
def waitForVpcCreation(vpcName, timeout=3000, interval=1):
    client = ntnx_networking_py_client.ApiClient(configuration=sdkConfig)
    vpcsApi = ntnx_networking_py_client.VpcsApi(api_client=client)
    vpcs = vpcsApi.list_vpcs()

    elapsedTime = 0
    while elapsedTime < timeout:
        vpcId = checkVpcExists(vpcs.data, vpcName)
        if vpcId:
            return vpcId
        else:
            time.sleep(interval)
            elapsedTime += interval

    return False


# Function to retrieve subnets in a VPC
def retrieveVpcSubnets(vpcId, timeout=3000, interval=1):
    subnetList = []
    nbPages = 10000
    page = 0
    limitPerPage = 50

    client = ntnx_networking_py_client.ApiClient(configuration=sdkConfig)
    subnetApi = ntnx_networking_py_client.SubnetsApi(api_client=client)

    while page < nbPages:
        response = subnetApi.list_subnets(_page=page, _limit=limitPerPage, _filter="vpcReference eq '" + vpcId + "'")
        myData = response.to_dict()

        nbPages = math.ceil(myData['metadata']['total_available_results'] / limitPerPage)

        for item in myData['data']:
            subnetList.append({'name': item['name'], 'ext_id': item['ext_id']})
        page += 1

    return subnetList

# Function to retrieve the extId of a specific subnet
def retrieveNetworkId(networkName):
    client = ntnx_networking_py_client.ApiClient(configuration=sdkConfig)
    subnetApi = ntnx_networking_py_client.SubnetsApi(api_client=client)

    response = subnetApi.list_subnets(_filter="name eq '" + str(networkName) + "'")
    myData = response.to_dict()

    if myData['data']:
        return myData['data'][0]['ext_id']
    else:
        return None

# Function to get VMs by categories
def getVmsByCategories(categoryName, categoryValue):
    vmList = []
    nbPages = 10000
    page = 0
    limitPerPage = 50

    client = ntnx_vmm_py_client.ApiClient(configuration=sdkConfig)
    vmApi = ntnx_vmm_py_client.VmApi(api_client=client)

    categoryId = getCategoryId(categoryName, categoryValue)

    while page < nbPages:
        # Temporary filter only on VM starting with 'hol' to bypass the UEFI issue
        response = vmApi.list_vms(_page=page, _limit=limitPerPage, _orderby="name asc")
        myData = response.to_dict()

        nbPages = math.ceil(myData['metadata']['total_available_results'] / limitPerPage)

        if myData['data'] and len(myData['data']):
            for item in myData['data']:
                if item.get('categories') is not None:
                    for category in item['categories']:
                        if category['ext_id'] == categoryId:
                            vmList.append({'name': item['name'], 'ext_id': item['ext_id']})
        page += 1

    return vmList

# Function to get category ID by name and value
def getCategoryId(name, value):
    page = 0
    limitPerPage = 50

    client = ntnx_prism_py_client.ApiClient(configuration=sdkConfig)
    categoriesApi = ntnx_prism_py_client.CategoriesApi(api_client=client)

    try:
        apiResponse = categoriesApi.list_categories(_page=page, _limit=limitPerPage, _filter="((value eq '"+value+"') and (key eq '"+name+"'))")
        if apiResponse.to_dict()['data']:
            return apiResponse.to_dict()['data'][0]['ext_id']
        else:
            return None
    except ntnx_prism_py_client.rest.ApiException as e:
        print(e)

# A successful HTTP response only accepts the asynchronous operation.
def waitOperation(response, label, maxPolls=120):
    data = response.to_dict() if hasattr(response, "to_dict") else response
    task = (data.get("data") or {}).get("ext_id") or (data.get("data") or {}).get("extId")
    if not task:
        raise RuntimeError("%s returned no task; inspect its outcome before retrying" % label)
    for _ in range(maxPolls):
        r = requests.get("https://%s:9440/api/prism/v4.0/config/tasks/%s" % (prismCentralIp, task),
                         auth=(pcUsername, pcPassword), verify=False, timeout=30)
        r.raise_for_status()
        result = r.json()["data"]
        if result.get("status") == "SUCCEEDED":
            return
        if result.get("status") in ("FAILED", "ABORTED", "CANCELLED"):
            raise RuntimeError("%s failed: %s" % (label, json.dumps(result.get("errorMessages", []))))
        time.sleep(2)
    raise RuntimeError("%s timed out; inspect its task before retrying" % label)


def shareCloneSubnet(vmId, networkExtId):
    # Clone inherits the source project. Share only the selected destination subnet.
    base = "https://%s:9440" % prismCentralIp
    auth = (pcUsername, pcPassword)
    r = requests.get(base + "/api/nutanix/v3/vms/" + vmId, auth=auth, verify=False, timeout=30)
    r.raise_for_status()
    project = r.json().get("metadata", {}).get("project_reference", {}).get("uuid")
    if not project or project == "00000000-0000-0000-0000-000000000000":
        raise RuntimeError("Cannot resolve source VM project for subnet sharing")
    path = base + "/api/networking/v4.4/config/subnets/" + networkExtId
    r = requests.get(path, auth=auth, verify=False, timeout=30)
    r.raise_for_status()
    headers = {"If-Match": r.headers["ETag"], "NTNX-Request-Id": str(uuid.uuid4())}
    r = requests.post(path + "/$actions/share", json={"projectExtId": project}, headers=headers,
                      auth=auth, verify=False, timeout=30)
    r.raise_for_status()
    waitOperation(r.json(), "Share clone subnet")


def cloneWithProjectScope(clone, vmId, networkExtId):
    try:
        waitOperation(clone(), "Clone VM")
    except RuntimeError as err:
        # Only a confirmed project/subnet rejection warrants sharing and one retry.
        if "VMM-31701" not in str(err) or "Subnet" not in str(err):
            raise
        shareCloneSubnet(vmId, networkExtId)
        waitOperation(clone(), "Clone VM retry")


# Function to clone a VM by its ID
def cloneVmById(vmOriginalName, vmId, networkExtId, vmName, powerup=False):
    client = ntnx_vmm_py_client.ApiClient(configuration=sdkConfig)
    vmApi = ntnx_vmm_py_client.VmApi(api_client=client)

    print(" - Cloning VM %s to %s" % (vmOriginalName, vmName))

    try:
        # Retrieve the VM
        vm = vmApi.get_vm_by_id(extId=vmId)
        etagValue = client.get_etag(vm)

        # Define the NIC
        nics = [
            Nic(
                network_info=NicNetworkInfo(
                    subnet=SubnetReference(ext_id=networkExtId)
                )
            )
        ]

        cloneConfig = CloneOverrideParams(
            name=vmName,
            nics=nics,
        )

        def submitClone():
            fresh = vmApi.get_vm_by_id(extId=vmId)
            return vmApi.clone_vm(extId=vmId, body=cloneConfig, if_match=client.get_etag(fresh), async_req=False)
        cloneWithProjectScope(submitClone, vmId, networkExtId)

        #retrieve the category ID matching
        categoryFloatingIPExtId = getCategoryId(categoryFloatingIPName, categoryFloatingIPValue)

        #check if source VM has the floating IP category
        if vm.data.categories is not None:
            for category in vm.data.categories:
                if category.ext_id == categoryFloatingIPExtId:
                    assignFloatingIp(vmName)

        if powerup:
            # we get cloneId
            for _ in range(60):
                response = vmApi.list_vms(_filter="name eq '"+vmName+"'")
                myData = response.to_dict()
                if myData['data']:
                    break
                time.sleep(2)
            else:
                raise RuntimeError("Clone task succeeded but VM %s is not visible" % vmName)
        
            clonedVMUUID = myData['data'][0]['ext_id']
            getClonedVM = vmApi.get_vm_by_id(extId=clonedVMUUID)
            etagCloneValue = client.get_etag(getClonedVM)

            print("   Powering up the VM")
            waitOperation(vmApi.power_on_vm(extId=clonedVMUUID,if_match=etagCloneValue,async_req=False), "Power on clone")                    

    except VMMException:
        raise

# Function to create a default route
def createDefaultRoute(vpcId):
    externalNetworkId = retrieveNetworkId(externalNetworkName)
    
    # Get list of route tables
    url="https://%s:9440/api/networking/v4.0.b1/config/route-tables" % prismCentralIp
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
    }
    
    response = requests.request("GET", url, headers=headers, verify=False, auth=(pcUsername, pcPassword))
    response_data = json.loads(response.text)
    
    jsonparse_expr = parse("data[?(@.vpcReference == '"+vpcId+"')].extId")
    for match in jsonparse_expr.find(response_data):
        routeTableId=match.value
    
            
    url="https://%s:9440/api/networking/v4.0.b1/config/route-tables/%s" % (prismCentralIp, routeTableId)
    
    
    response = requests.request("GET", url, headers=headers, verify=False, auth=(pcUsername, pcPassword))
    etagValue = response.headers._store['etag'][1]    
    
    url="https://%s:9440/api/networking/v4.0.b1/config/route-tables/%s" % (prismCentralIp, routeTableId)
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'If-Match': etagValue,
        'NTNX-Req-Id': str(uuid.uuid4())
    }
    payload={
        "staticRoutes": [
            {
                "destination": {
                    "ipv4": {
                        "$reserved": {
                            "$fv": "v1.r0.b1"
                        },
                        "$objectType": "common.v1.config.IPv4Address",
                        "value": "0.0.0.0",
                        "prefixLength": 0
                    },
                "nexthopType": "EXTERNAL_SUBNET",
                "nexthopReference": externalNetworkName
                }
            }
        ]
        
    }
    
    # Not supported yet : METHOD NOT ALLOWED returned
    # response = requests.request("PUT", url, headers=headers, data=payload, verify=False, auth=(pcUsername, pcPassword))
    


# Function to get Floating IP from VM
def getFloatingIP(vmName):
    
    client = ntnx_networking_py_client.ApiClient(configuration=sdkConfig)
    floating_ips_api = ntnx_networking_py_client.FloatingIpsApi(api_client=client)

    try:
        response = floating_ips_api.list_floating_ips()
        response_data = response.to_dict()
    except ntnx_networking_py_client.rest.ApiException as e:
        print(e)

    jsonparse_expr = parse("data[?(@.name == '"+vmName+"')].ext_id")
    
    for match in jsonparse_expr.find(response_data):
        floatingIpId=match.value
    
    floating_ips_api = ntnx_networking_py_client.FloatingIpsApi(api_client=client)
    
    try:
        response = floating_ips_api.get_floating_ip_by_id(extId=floatingIpId)
        response_data = response.to_dict()
        floatingIp = response_data['data']['floating_ip']['ipv4']['value']
    except ntnx_networking_py_client.rest.ApiException as e:
        print(e)
    
    return(floatingIp)
    
# Function to create a floating IP
def assignFloatingIp(vmName):
    client = ntnx_networking_py_client.ApiClient(configuration=sdkConfig)
    floatingIpApi = ntnx_networking_py_client.FloatingIpsApi(api_client=client)

    client = ntnx_vmm_py_client.ApiClient(configuration=sdkConfig)
    vmApi = ntnx_vmm_py_client.VmApi(api_client=client)


    floatingIpConfig = v4NetConfig.FloatingIp.FloatingIp()
    vmNicAssociation = v4NetConfig.VmNicAssociation.VmNicAssociation()

    elapsed_time = 0    # time elapsed since the start of the retries
    while elapsed_time < max_wait_time:
        if vmApi.list_vms(_filter="name eq '" + vmName + "'").data is not None:

            vmNicAssociation.vm_nic_reference = vmApi.list_vms(_filter="name eq '" + vmName + "'").data[0].nics[0].ext_id
            break

        print("waiting for VM to be created to assign floating IP")

        # Wait for the specified interval before retrying
        time.sleep(interval)
        elapsed_time += interval  # Update the elapsed time

    floatingIpConfig.name = vmName
    floatingIpConfig.external_subnet_reference = retrieveNetworkId(externalNetworkName)
    floatingIpConfig.association = vmNicAssociation
    
    try:
        response=floatingIpApi.create_floating_ip(body=floatingIpConfig,async_req=False)
        response_data = response.data.to_dict()
    except ntnx_networking_py_client.rest.ApiException as e:
        print(e)
        
    ip=getFloatingIP(vmName)
         
    print("   Assigning floating IP to VM " , vmName, ":", ip)

# Main execution function
def main():
    vpcId = waitForVpcCreation(vpcName)

    vpcSubnets = retrieveVpcSubnets(vpcId)

    print("Cloning VM...")
    for vm in vmList:
        # Skip VMs that are themselves clones from a previous run: cloning
        # them would yield clone-clone-<name> (then clone-clone-clone-... on
        # every replay). Only the production originals get cloned.
        if vm['name'].startswith("clone-"):
            print(" - skip %s (already a clone)" % vm['name'])
            continue
        cloneVmById(vm['name'],vm['ext_id'], vpcSubnets[0]['ext_id'], "clone-" + vm['name'], powerup=True)

    print("Done. %s VMs have been cloned" % len(vmList))

if __name__ == "__main__":
    main()
