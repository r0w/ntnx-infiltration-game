# Variables from the environment
pc_address = "@@{pcAddress}@@"
username = "@@{pcUser.username}@@"
password = "@@{pcUser.secret}@@"

# Function to make GET requests using urlreq
def get_request(api_url, username, password):
    try:
        # Make the GET request with basic authentication
        response = urlreq(api_url, verb='GET', auth="BASIC", user=username, passwd=password, verify=False)
        if response.ok:
            # Parse JSON content
            return json.loads(response.content)
        else:
            print(f"Error: {response.status_code} - {response.content}")
            exit(1)
    except Exception as err:
        print(f"Error making API request: {err}")
        exit(1)

# Initialize variables for pagination
page = 0
all_keys = set()  # Use a set to store unique keys

while True:
    # Construct the API URL with pagination
    api_url = f"https://{pc_address}:9440/api/prism/v4.0.b1/config/categories?$select=key&$page={page}"
    
    # Make the GET request to retrieve the category keys
    response_data = get_request(api_url, username, password)

    # Check if there is data returned
    if 'data' in response_data and response_data['data']:
        # Extract the 'key' values and add them to the set
        keys = {item['key'] for item in response_data['data']}
        all_keys.update(keys)  # Add new keys to the set (automatically removes duplicates)
        page += 1  # Increment the page number
    else:
        break  # Exit the loop if no data is returned

# Print the unique keys as a comma-separated string, sorted alphabetically
print(",".join(sorted(all_keys)))