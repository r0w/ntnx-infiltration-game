#!python3

import os
import time
import math

import ntnx_networking_py_client
import ntnx_vmm_py_client
import ntnx_prism_py_client
import ntnx_networking_py_client.models
import ntnx_networking_py_client.models.networking
import ntnx_networking_py_client.models.common.v1.config as v1CommonConfig
import ntnx_networking_py_client.models.networking.v4.config as v4NetConfig
import requests
import uuid
from ntnx_vmm_py_client.models.vmm.v4.ahv.config.CloneOverrideParams import CloneOverrideParams
from ntnx_vmm_py_client.models.vmm.v4.ahv.config.Nic import Nic
from ntnx_vmm_py_client.models.vmm.v4.ahv.config.NicNetworkInfo import NicNetworkInfo
from ntnx_vmm_py_client.models.vmm.v4.ahv.config.SubnetReference import SubnetReference
from ntnx_vmm_py_client.rest import ApiException as VMMException
from jsonpath_ng.ext import parse
import json

import urllib3
urllib3.disable_warnings()

# Load environment variables
#load_dotenv()

# Customizable variables
prismCentralIp = "@@{pcAddress}@@"  # Prism Central IP
pcUsername = "@@{pcUser.username}@@"  # Nutanix username
pcPassword = "@@{pcUser.secret}@@"  # Nutanix password
vpcName = "@@{vpcName}@@"
categoryName = "@@{categoryName}@@"
categoryValue = "@@{categoryValue}@@"
externalNetworkName = "@@{externalNetworkName}@@"
categoryFloatingIPName = "@@{categoryFloatingIPName}@@"
categoryFloatingIPValue = "Yes"
# Retry parameters
max_wait_time = 60  # maximum wait time in seconds
interval = 1        # interval between retries in seconds

# Subnet configuration
subnetList = {
    "vpc-"+vpcName+"-subnet": {
        "subnetDescription": "This is the overlay subnet",
        "ipNetwork": "10.55.182.0",
        "ipPrefix": 25,
        "ipGateway": "10.55.182.1",
        "ipPoolStart": "10.55.182.10",
        "ipPoolEnd": "10.55.182.120"
    },
}

#########################################
# SDK Client Configuration
#########################################

# Configure the client
sdkConfig = ntnx_networking_py_client.Configuration()
sdkConfig.host = prismCentralIp
sdkConfig.port = 9440
sdkConfig.maxRetryAttempts = 3
sdkConfig.backoffFactor = 3
sdkConfig.username = pcUsername
sdkConfig.password = pcPassword
sdkConfig.verify_ssl = False

# Function to create a VPC
def createVpc(vpcName):
    print("Creating VPC: %s" % vpcName)

    client = ntnx_networking_py_client.ApiClient(configuration=sdkConfig)
    vpcsApi = ntnx_networking_py_client.VpcsApi(api_client=client)
    vpc = ntnx_networking_py_client.Vpc()
    externalSubnet = ntnx_networking_py_client.ExternalSubnet()
    externalSubnet.subnet_reference = retrieveNetworkId(externalNetworkName)
    vpc.name = vpcName  # Required field
    vpc.external_subnets = [externalSubnet]

    try:
        response = vpcsApi.create_vpc(body=vpc)
        return True
    except ntnx_networking_py_client.rest.ApiException as e:
        return False

# Function to check if a VPC exists
def checkVpcExists(vpcData, vpcName):
    if vpcData:
      for vpc in vpcData:
          if vpc.name == vpcName:
              return vpc._ExternalizableAbstractModel__ext_id
    return False

# Function to wait for VPC creation
def waitForVpcCreation(vpcName, timeout=3000, interval=1):
    client = ntnx_networking_py_client.ApiClient(configuration=sdkConfig)
    vpcsApi = ntnx_networking_py_client.VpcsApi(api_client=client)
    vpcs = vpcsApi.list_vpcs()

    elapsedTime = 0
    while elapsedTime < timeout:
        vpcId = checkVpcExists(vpcs.data, vpcName)
        if vpcId:
            return vpcId
        else:
            time.sleep(interval)
            elapsedTime += interval

    return False

# Function to create an overlay subnet
def createOverlaySubnet(vpcId, subnetName, ipNetwork, ipPrefix, ipGateway, ipPoolStart, ipPoolEnd):
    client = ntnx_networking_py_client.ApiClient(configuration=sdkConfig)
    subnetsApi = ntnx_networking_py_client.SubnetsApi(api_client=client)
    subnet = ntnx_networking_py_client.Subnet()

    print("Creating overlay subnet...")

    # Set up the subnet configuration
    subnet.name = subnetName
    subnet.subnet_type = ntnx_networking_py_client.SubnetType.OVERLAY  # Required field
    subnet.vpc_reference = vpcId

    subnet.ip_config = [
        v4NetConfig.IPConfig.IPConfig(
            ipv4=v4NetConfig.IPv4Config.IPv4Config(
                default_gateway_ip=v1CommonConfig.IPv4Address.IPv4Address(
                    prefix_length=ipPrefix,
                    value=ipGateway,
                ),
                ip_subnet=v4NetConfig.IPv4Subnet.IPv4Subnet(
                    ip=v1CommonConfig.IPv4Address.IPv4Address(
                        prefix_length=ipPrefix,
                        value=ipNetwork,
                    ),
                    prefix_length=ipPrefix,
                ),
                pool_list=[
                    v4NetConfig.IPv4Pool.IPv4Pool(
                        start_ip=v1CommonConfig.IPv4Address.IPv4Address(
                            prefix_length=ipPrefix,
                            value=ipPoolStart,
                        ),
                        end_ip=v1CommonConfig.IPv4Address.IPv4Address(
                            prefix_length=ipPrefix,
                            value=ipPoolEnd,
                        )
                    )
                ],
            )
        )
    ]

    try:
        subnetsApi.create_subnet(body=subnet)
        print("Done...")
    except ntnx_networking_py_client.rest.ApiException as e:
        print(e)

# Function to retrieve subnets in a VPC
def retrieveVpcSubnets(vpcId, timeout=3000, interval=1):
    subnetList = []
    nbPages = 10000
    page = 0
    limitPerPage = 50

    client = ntnx_networking_py_client.ApiClient(configuration=sdkConfig)
    subnetApi = ntnx_networking_py_client.SubnetsApi(api_client=client)

    while page < nbPages:
        response = subnetApi.list_subnets(_page=page, _limit=limitPerPage, _filter="vpcReference eq '" + vpcId + "'")
        myData = response.to_dict()

        nbPages = math.ceil(myData['metadata']['total_available_results'] / limitPerPage)

        for item in myData['data']:
            subnetList.append({'name': item['name'], 'ext_id': item['ext_id']})
        page += 1

    return subnetList

# Function to retrieve the extId of a specific subnet
def retrieveNetworkId(networkName):
    client = ntnx_networking_py_client.ApiClient(configuration=sdkConfig)
    subnetApi = ntnx_networking_py_client.SubnetsApi(api_client=client)

    response = subnetApi.list_subnets(_filter="name eq '" + str(networkName) + "'")
    myData = response.to_dict()

    if myData['data']:
        return myData['data'][0]['ext_id']
    else:
        return None

# Function to get VMs by categories
def getVmsByCategories(categoryName, categoryValue):
    vmList = []
    nbPages = 10000
    page = 0
    limitPerPage = 50

    client = ntnx_vmm_py_client.ApiClient(configuration=sdkConfig)
    vmApi = ntnx_vmm_py_client.VmApi(api_client=client)

    categoryId = getCategoryId(categoryName, categoryValue)

    while page < nbPages:
        # Temporary filter only on VM starting with 'hol' to bypass the UEFI issue
        response = vmApi.list_vms(_page=page, _limit=limitPerPage, _orderby="name asc")
        myData = response.to_dict()

        nbPages = math.ceil(myData['metadata']['total_available_results'] / limitPerPage)

        if myData['data'] and len(myData['data']):
            for item in myData['data']:
                if item.get('categories') is not None:
                    for category in item['categories']:
                        if category['ext_id'] == categoryId:
                            vmList.append({'name': item['name'], 'ext_id': item['ext_id']})
        page += 1

    return vmList

# r0w: Returns the set of VM ext_ids belonging to a Calm project.
# Used to intersect with the category-based filter so CloneProd only clones
# VMs that are BOTH tagged Environment=Production AND in the `production`
# project — which isolates it from foreign VMs on shared clusters that happen
# to share the Production tag (e.g. lab VMs in `_internal`). On vanilla HPoC
# this is a no-op (only our prd-* VMs carry the tag and live in the project).
# v3 /vms/list is used because v4 vmm doesn't surface project_reference.
def getVmExtIdsByProject(projectName):
    url = "https://%s:9440/api/nutanix/v3/vms/list" % prismCentralIp
    auth = (pcUsername, pcPassword)
    headers = {"Content-Type": "application/json", "Accept": "application/json"}
    extIds = set()
    offset = 0
    length = 250
    while True:
        body = {"kind": "vm", "length": length, "offset": offset}
        r = requests.post(url, json=body, headers=headers, auth=auth, verify=False, timeout=30)
        r.raise_for_status()
        entities = r.json().get('entities') or []
        for e in entities:
            pref = (e.get('metadata') or {}).get('project_reference') or {}
            if pref.get('name') == projectName:
                extIds.add(e.get('metadata', {}).get('uuid'))
        if len(entities) < length:
            break
        offset += length
    return extIds

# Function to get category ID by name and value
def getCategoryId(name, value):
    page = 0
    limitPerPage = 50

    client = ntnx_prism_py_client.ApiClient(configuration=sdkConfig)
    categoriesApi = ntnx_prism_py_client.CategoriesApi(api_client=client)

    try:
        apiResponse = categoriesApi.list_categories(_page=page, _limit=limitPerPage, _filter="((value eq '"+value+"') and (key eq '"+name+"'))")
        if apiResponse.to_dict()['data']:
            return apiResponse.to_dict()['data'][0]['ext_id']
        else:
            return None
    except ntnx_prism_py_client.rest.ApiException as e:
        print(e)

# Function to clone a VM by its ID
def cloneVmById(vmOriginalName, vmId, networkExtId, vmName, powerup=False):
    client = ntnx_vmm_py_client.ApiClient(configuration=sdkConfig)
    vmApi = ntnx_vmm_py_client.VmApi(api_client=client)

    print(" - Cloning VM %s to %s" % (vmOriginalName, vmName))

    try:
        # Retrieve the VM
        vm = vmApi.get_vm_by_id(extId=vmId)
        etagValue = client.get_etag(vm)

        # Define the NIC
        nics = [
            Nic(
                network_info=NicNetworkInfo(
                    subnet=SubnetReference(ext_id=networkExtId)
                )
            )
        ]

        cloneConfig = CloneOverrideParams(
            name=vmName,
            nics=nics,
        )

        vmApi.clone_vm(extId=vmId, body=cloneConfig, if_match=etagValue, async_req=False)
        time.sleep(3)

        #retrieve the category ID matching
        categoryFloatingIPExtId = getCategoryId(categoryFloatingIPName, categoryFloatingIPValue)

        #check if source VM has the floating IP category
        if vm.data.categories is not None:
            for category in vm.data.categories:
                if category.ext_id == categoryFloatingIPExtId:
                    assignFloatingIp(vmName)

        if powerup:
            # we get cloneId
            found=False
            while not found:
                response = vmApi.list_vms(_filter="name eq '"+vmName+"'")
                myData = response.to_dict()

                if myData['data']:
                    found = True
        
            clonedVMUUID = myData['data'][0]['ext_id']
            getClonedVM = vmApi.get_vm_by_id(extId=clonedVMUUID)
            etagCloneValue = client.get_etag(getClonedVM)

            print("   Powering up the VM")
            vmApi.power_on_vm(extId=clonedVMUUID,if_match=etagCloneValue,async_req=False)                    

    except VMMException as e:
        print(e)

# Function to create a default route
def createDefaultRoute(vpcId):
    externalNetworkId = retrieveNetworkId(externalNetworkName)
    
    # Get list of route tables
    url="https://%s:9440/api/networking/v4.0.b1/config/route-tables" % prismCentralIp
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
    }
    
    response = requests.request("GET", url, headers=headers, verify=False, auth=(pcUsername, pcPassword))
    response_data = json.loads(response.text)
    
    jsonparse_expr = parse("data[?(@.vpcReference == '"+vpcId+"')].extId")
    for match in jsonparse_expr.find(response_data):
        routeTableId=match.value
    
            
    url="https://%s:9440/api/networking/v4.0.b1/config/route-tables/%s" % (prismCentralIp, routeTableId)
    
    
    response = requests.request("GET", url, headers=headers, verify=False, auth=(pcUsername, pcPassword))
    etagValue = response.headers._store['etag'][1]    
    
    url="https://%s:9440/api/networking/v4.0.b1/config/route-tables/%s" % (prismCentralIp, routeTableId)
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'If-Match': etagValue,
        'NTNX-Req-Id': str(uuid.uuid4())
    }
    payload={
        "staticRoutes": [
            {
                "destination": {
                    "ipv4": {
                        "$reserved": {
                            "$fv": "v1.r0.b1"
                        },
                        "$objectType": "common.v1.config.IPv4Address",
                        "value": "0.0.0.0",
                        "prefixLength": 0
                    },
                "nexthopType": "EXTERNAL_SUBNET",
                "nexthopReference": externalNetworkName
                }
            }
        ]
        
    }
    
    # Not supported yet : METHOD NOT ALLOWED returned
    # response = requests.request("PUT", url, headers=headers, data=payload, verify=False, auth=(pcUsername, pcPassword))
    


# Function to get Floating IP from VM
def getFloatingIP(vmName):
    
    client = ntnx_networking_py_client.ApiClient(configuration=sdkConfig)
    floating_ips_api = ntnx_networking_py_client.FloatingIpsApi(api_client=client)

    try:
        response = floating_ips_api.list_floating_ips()
        response_data = response.to_dict()
    except ntnx_networking_py_client.rest.ApiException as e:
        print(e)

    jsonparse_expr = parse("data[?(@.name == '"+vmName+"')].ext_id")
    
    for match in jsonparse_expr.find(response_data):
        floatingIpId=match.value
    
    floating_ips_api = ntnx_networking_py_client.FloatingIpsApi(api_client=client)
    
    try:
        response = floating_ips_api.get_floating_ip_by_id(extId=floatingIpId)
        response_data = response.to_dict()
        floatingIp = response_data['data']['floating_ip']['ipv4']['value']
    except ntnx_networking_py_client.rest.ApiException as e:
        print(e)
    
    return(floatingIp)
    
# Function to create a floating IP
def assignFloatingIp(vmName):
    client = ntnx_networking_py_client.ApiClient(configuration=sdkConfig)
    floatingIpApi = ntnx_networking_py_client.FloatingIpsApi(api_client=client)

    client = ntnx_vmm_py_client.ApiClient(configuration=sdkConfig)
    vmApi = ntnx_vmm_py_client.VmApi(api_client=client)


    floatingIpConfig = v4NetConfig.FloatingIp.FloatingIp()
    vmNicAssociation = v4NetConfig.VmNicAssociation.VmNicAssociation()

    elapsed_time = 0    # time elapsed since the start of the retries
    while elapsed_time < max_wait_time:
        if vmApi.list_vms(_filter="name eq '" + vmName + "'").data is not None:

            vmNicAssociation.vm_nic_reference = vmApi.list_vms(_filter="name eq '" + vmName + "'").data[0].nics[0].ext_id
            break

        print("waiting for VM to be created to assign floating IP")

        # Wait for the specified interval before retrying
        time.sleep(interval)
        elapsed_time += interval  # Update the elapsed time

    floatingIpConfig.name = vmName
    floatingIpConfig.external_subnet_reference = retrieveNetworkId(externalNetworkName)
    floatingIpConfig.association = vmNicAssociation
    
    try:
        response=floatingIpApi.create_floating_ip(body=floatingIpConfig,async_req=False)
        response_data = response.data.to_dict()
    except ntnx_networking_py_client.rest.ApiException as e:
        print(e)
        
    ip=getFloatingIP(vmName)
         
    print("   Assigning floating IP to VM " , vmName, ":", ip)

# Main execution function
def main():
    vpcId = createVpc(vpcName)
    vpcId = waitForVpcCreation(vpcName)
    print("VPC Created")

    # Create the VPC network
    for key, value in subnetList.items():
        createOverlaySubnet(
            vpcId,
            key,
            value['ipNetwork'],
            value['ipPrefix'],
            value['ipGateway'],
            value['ipPoolStart'],
            value['ipPoolEnd']
        )

    print("Get VM list from category %s=%s" % (categoryName, categoryValue))
    vmList = getVmsByCategories(categoryName, categoryValue)
    # r0w: intersect with the `production` project membership so we don't
    # clone VMs that happen to share Environment=Production but live in
    # another project (foreign workloads on a shared cluster).
    projectVmIds = getVmExtIdsByProject('production')
    beforeCount = len(vmList)
    vmList = [v for v in vmList if v['ext_id'] in projectVmIds]
    print("Filtered by project=production: %d -> %d VMs" % (beforeCount, len(vmList)))
    print("Done...")

    vpcSubnets = retrieveVpcSubnets(vpcId)

    print("Cloning VM...")
    for vm in vmList:
        cloneVmById(vm['name'],vm['ext_id'], vpcSubnets[0]['ext_id'], "clone-" + vm['name'], powerup=True)

    #skip the route creation for now as the endpoint changed with PC 2024.2 but no SDK is yet published
    createDefaultRoute(vpcId)

    print("Done. %s VMs have been cloned" % len(vmList))

if __name__ == "__main__":
    main()
