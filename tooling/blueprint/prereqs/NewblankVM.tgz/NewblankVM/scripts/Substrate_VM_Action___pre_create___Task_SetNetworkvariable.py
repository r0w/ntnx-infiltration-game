# Get the JWT
jwt = '@@{calm_jwt}@@'
pc_ip="pc.ntnxlab.org"
myNetwork="""@@{Network}@@""".strip()


## Create the Karbon Kubernetes cluster
# Set the headers, payload, and cookies
#GLheaders = {'Content-Type': 'application/json', 'Accept': 'application/json'}
headers = {'Content-Type': 'application/json', 'Accept': 'application/json', 'Authorization': 'Bearer {}'.format(jwt)}
payload={}


  # Set the address and make images call
url = "https://"+pc_ip+":9440/api/nutanix/v3/subnets/list"

resp = urlreq(url, verb='POST',  params=json.dumps(payload), headers=headers, verify=False)
#GL resp = urlreq(url, verb='POST',  params=json.dumps(payload), headers=headers, verify=False, auth="BASIC", user='admin', passwd='nx2Tech736!')

# If the call went through successfully, find the image by name
if resp.ok:
  subnets_list = json.loads(resp.content)
  for subnet in subnets_list['entities']:
      if (subnet['spec']['name'] == myNetwork ):
          print("SelectedNetwork={\"name\": \""+subnet['spec']['name']+"\", \"uuid\": \""+subnet['metadata']['uuid']+"\" }")
          