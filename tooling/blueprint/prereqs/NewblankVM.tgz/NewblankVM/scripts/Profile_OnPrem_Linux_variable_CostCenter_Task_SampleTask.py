#script

import requests

#Get conf file from confserver depending project name
url="http://@@{ConfServer}@@/@@{calm_project_name}@@.json"

out=requests.get(url)

#If conf fail is missing, use default one
if out.status_code == 404:
   url="http://@@{ConfServer}@@/Default.json"
   out=requests.get(url) 

donnees=json.loads(out.text)

out=requests.get(url,verify=False)

tmp=out.json()['Cost_Center']

separator=","

print(separator.join(tmp))
