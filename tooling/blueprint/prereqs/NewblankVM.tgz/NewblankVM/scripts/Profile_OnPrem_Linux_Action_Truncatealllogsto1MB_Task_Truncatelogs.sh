#!/bin/bash

sudo find / -name *.log -exec truncate -s 1000000 {} \;