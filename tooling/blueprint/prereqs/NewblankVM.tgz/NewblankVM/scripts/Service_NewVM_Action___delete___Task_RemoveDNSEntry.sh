#!/bin/bash

SHORTNAME=`echo @@{VMHostname}@@ | awk -F'.' '{ print $1 }'`
DOMAIN=`echo @@{VMHostname}@@ | cut -d'.' -f2-`

ZONEFILE=`sudo ls /var/named/zone.$DOMAIN`


if [ "$ZONEFILE" == "" ]
then
   echo "No config file found for zone $DOMAIN"
   exit 2
fi

sudo grep -v "^$SHORTNAME    A" $ZONEFILE > /tmp/dns.tmp

sudo mv /tmp/dns.tmp $ZONEFILE

echo "Entry removed from $ZONEFILE"

sudo systemctl reload named
echo "named reloaded"


