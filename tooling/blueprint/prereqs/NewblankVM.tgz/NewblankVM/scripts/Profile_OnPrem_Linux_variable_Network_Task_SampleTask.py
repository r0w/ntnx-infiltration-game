# Get the JWT
jwt = '@@{calm_jwt}@@'
pc_ip="pc.ntnxlab.org"

## Create the Karbon Kubernetes cluster
# Set the headers, payload, and cookies
#GL headers = {'Content-Type': 'application/json', 'Accept': 'application/json'}
headers = {'Content-Type': 'application/json', 'Accept': 'application/json', 'Authorization': 'Bearer {}'.format(jwt)}
payload={}


  # Set the address and make images call
url = "https://"+pc_ip+":9440/api/nutanix/v3/environments/list"
resp = urlreq(url, verb='POST',  params=json.dumps(payload), headers=headers, verify=False)
#GL resp = urlreq(url, verb='POST',  params=json.dumps(payload), headers=headers, verify=False, auth="BASIC", user='admin', passwd='nx2Tech736!')
subnets = []

  # If the call went through successfully, find the image by name
if resp.ok:
  environments_list = json.loads(resp.content)
  for env in environments_list['entities']:
    if ( env['metadata']['name'] == "@@{calm_environment_name}@@" ):
        # We found an environment with same name, check project
        if ( env['metadata']['project_reference']['name'] == "@@{calm_project_name}@@" ):
            for infra in env['status']['resources']['infra_inclusion_list']:
                try:
                    for net in infra['subnet_references']:
                        # We have a Network ID. Looking for the network name
                        url = "https://"+pc_ip+":9440/api/nutanix/v3/subnets/"+net['uuid']
                        resp = urlreq(url, verb='GET', headers=headers, verify=False)
                        
                        if resp.ok:
                            subnets.append(json.loads(resp.content)['spec']['name'])

                except:
                    print("")

else:
  print("Request failed",resp.__dict__)
  exit(2)
  
print(",".join(subnets))