#script

import requests

customername="@@{calm_project_name}@@".replace(" ","_")


#Get conf file from confserver depending project name
url="http://@@{ConfServer}@@/"+customername+".json"

out=requests.get(url)

#If conf fail is missing, use default one
if out.status_code == 404:
   url="http://@@{ConfServer}@@/Default.json"
   out=requests.get(url) 

donnees=json.loads(out.text)

print("IPAM_Server="+donnees['IPAM_Server'])
print("IPAM_API_Key="+donnees['IPAM_API_Key'])
print("IPAM_SubnetID="+donnees['IPAM_SubnetID']['@@{ProfileName}@@'])
print("IPAM_App_ID="+donnees['IPAM_App_ID'])