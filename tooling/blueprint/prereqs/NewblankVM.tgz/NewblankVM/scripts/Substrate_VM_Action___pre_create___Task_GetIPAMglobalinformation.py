#script

import requests

url="https://@@{IPAM_Server}@@/api/@@{IPAM_App_ID}@@/subnets/@@{IPAM_SubnetID}@@"
headers={"token":"@@{IPAM_API_Key}@@"}

out=requests.get(url,headers=headers,verify=False)

donnees=out.json()['data']

print("NetMask="+donnees['calculation']['Subnet netmask'])
print("GW_Address="+donnees['gateway']['ip_addr'])
