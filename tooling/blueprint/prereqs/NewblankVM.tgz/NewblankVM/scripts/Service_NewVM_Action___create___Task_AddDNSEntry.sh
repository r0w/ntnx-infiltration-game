#!/bin/bash 

SHORTNAME=`echo @@{VMHostname}@@ | awk -F'.' '{ print $1 }'`
DOMAIN=`echo @@{VMHostname}@@ | cut -d'.' -f2-`

ZONEFILE=`sudo ls /var/named/zone.$DOMAIN`


if [ "$ZONEFILE" == "" ]
then
   echo "No config file found for zone $DOMAIN"
   exit 2
fi

sudo grep "@@{address}@@ " $ZONEFILE >/dev/null 2>&1

if [ $? -eq 0 ]
then
    echo "IP @@{NewIP}@@ is already in $ZONEFILE"
    exit 3
fi

sudo grep $SHORTNAME $ZONEFILE >/dev/null 2>&1

if [ $? -eq 0 ]
then
    echo "Hostname $SHORTNAME is already in $ZONEFILE"
    exit 3
fi

sudo sh -c "echo '$SHORTNAME    A    @@{address}@@' >> $ZONEFILE"

echo "New entry added in $ZONEFILE"

echo "New zone file :"
sudo echo $ZONEFILE

sudo systemctl reload named
echo "named reloaded"


