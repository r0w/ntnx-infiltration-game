#!/bin/sh

echo "Fichier à supprimer :"
sudo find / -name *.log -mtime +1 -exec ls -ltra {} \;

echo "Suppression..."
sudo find / -name *.log -mtime +1 -exec rm {} \;